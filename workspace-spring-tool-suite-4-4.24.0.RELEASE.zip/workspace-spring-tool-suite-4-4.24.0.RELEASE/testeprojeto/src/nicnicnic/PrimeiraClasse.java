package nicnicnic;

public class PrimeiraClasse {

	public static void main(String[] args) {
		System.out.print("HelloWorld");

	}

}

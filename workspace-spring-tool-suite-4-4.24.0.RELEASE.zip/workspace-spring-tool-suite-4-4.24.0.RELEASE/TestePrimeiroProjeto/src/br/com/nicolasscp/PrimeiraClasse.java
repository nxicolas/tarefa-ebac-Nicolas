package br.com.nicolasscp;

public class PrimeiraClasse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
